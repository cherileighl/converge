from django.apps import AppConfig


class ApplicantsConfig(AppConfig):
    name = 'applicants'
