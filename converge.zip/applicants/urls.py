from django.urls import path
from .views import allApplicantsView

urlpatterns = [
    path('all/', allApplicantsView, name="allApplicants")
    # applicant log in
    # path('pathname', viewName, name="myViewName")
    # create profile
    # edit profile
    # delete profile
    # view jobs 
]