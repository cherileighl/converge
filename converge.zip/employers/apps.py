from django.apps import AppConfig


class EmployersConfig(AppConfig):
    name = 'employers'
