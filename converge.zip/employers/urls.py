from django.urls import path
from .views import empCreateView, empProfileView, empLoginView, empSaveView

urlpatterns = [
    path('login/', empLoginView, name='loginCompany'),
    path('create/', empCreateView, name='createCompany'),
    path('profile/', empProfileView, name='companyProfile'),
    path('save/', empSaveView, name="saveCompany")

    # create company profile
    # edit company profile
    # delete company profile
    # create job
    # edit job
    # delete job
    # view applicants
    # create review
    # edit review
    # delete review
]